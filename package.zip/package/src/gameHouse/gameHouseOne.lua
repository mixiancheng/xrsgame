require "Cocos2d"
require "AudioEngine" 
backMusic="bg_music1.mp3"
local scheduler = cc.Director:getInstance():getScheduler()
local s = cc.Director:getInstance():getWinSize()
local gameHouseOne = class("gameHouseOne")
gameHouseOne.__index = gameHouseOne
gameHouseOne._uiLayer= nil
gameHouseOne._widget = nil
gameHouseOne._numberRole=nil
gameHouseOne._popButton=nil
gameHouseOne._meng=nil
gameHouseOne._house=nil
gameHouseOne._dog=nil
gameHouseOne._buttonTable=nil
waitAction={"wait1","wait2"}
EFFECT_FILE_NAME={"kaozheng.mp3","glass.mp3","a bottle of water.mp3","a cup of water.mp3","yi ge shui tong.mp3","a hat.mp3","a fishing rod.mp3"}
function gameHouseOne.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, gameHouseOne)
    return target
end
function gameHouseOne:waitAction()
    math.randomseed(os.time())
    local _index=math.random(1,2)
    self._numberRole:getNode():getAnimation():play(waitAction[_index])
end
function gameHouseOne:init()
    self._buttonTable={}
    self._uiLayer = cc.Layer:create()
    self:addChild(self._uiLayer)
    self._widget =ccs.SceneReader:getInstance():createNodeWithSceneFile("house_1_Scene.json")
    self._uiLayer:addChild(self._widget)
    self._numberRole = self._widget:getChildByTag(10016):getComponent("CCArmature")
    self._meng= self._widget:getChildByTag(10018)
    self._house= self._widget:getChildByTag(10012)
    self._dog=self._widget:getChildByTag(10017):getComponent("CCArmature")
    self._dog:getNode():getAnimation():play("bark")
--    self._dog:setVisible(false)
    local function initButton()
        local function eventButton_fly1(sender, eventType)
            if eventType == ccui.TouchEventType.ended then 
                AudioEngine.playEffect(EFFECT_FILE_NAME[1])
                sender:setVisible(false)
                self._house:getChildByTag(1):getChildByTag(7):getChildByName("Button_1"):setVisible(true)
            end 
        end
        local button_fl1=self._house:getChildByTag(1):getChildByName("Button_f1")
        button_fl1:addTouchEventListener(eventButton_fly1)
        
        local function eventButton_fly2(sender, eventType)
            if eventType == ccui.TouchEventType.ended then
                AudioEngine.playEffect(EFFECT_FILE_NAME[2]) 
            cclog("-->2")
                sender:setVisible(false)
                self._house:getChildByTag(1):getChildByTag(7):getChildByName("Button_2"):setVisible(true)
            end 
        end
        local button_fl2=self._house:getChildByTag(1):getChildByName("Button_f2")
        button_fl2:addTouchEventListener(eventButton_fly2)
        
        local function eventButton_fly3(sender, eventType)
            if eventType == ccui.TouchEventType.ended then
                AudioEngine.playEffect(EFFECT_FILE_NAME[3]) 
                cclog("-->3")
                sender:setVisible(false)
                self._house:getChildByTag(1):getChildByTag(7):getChildByName("Button_3"):setVisible(true)
            end 
        end
        local button_fl3=self._house:getChildByTag(1):getChildByName("Button_f3")
        button_fl3:addTouchEventListener(eventButton_fly3)
        
        local function eventButton_fly4(sender, eventType)
            if eventType == ccui.TouchEventType.ended then 
                AudioEngine.playEffect(EFFECT_FILE_NAME[4])
                cclog("-->4")
                sender:setVisible(false)
                self._house:getChildByTag(1):getChildByTag(7):getChildByName("Button_4"):setVisible(true)
            end 
        end
        local button_fl4=self._house:getChildByTag(1):getChildByName("Button_f4")
        button_fl4:addTouchEventListener(eventButton_fly4)
        
        local function eventButton_fly5(sender, eventType)
            if eventType == ccui.TouchEventType.ended then 
                AudioEngine.playEffect(EFFECT_FILE_NAME[5])
                cclog("-->5")
                sender:setVisible(false)
                self._house:getChildByTag(1):getChildByTag(7):getChildByName("Button_5"):setVisible(true)
            end 
        end
        local button_fl5=self._house:getChildByTag(1):getChildByName("Button_f5")
        button_fl5:addTouchEventListener(eventButton_fly5)
        
        local function eventButton_fly6(sender, eventType)
        
            if eventType == ccui.TouchEventType.ended then 
                AudioEngine.playEffect(EFFECT_FILE_NAME[6])
                cclog("-->6")
                sender:setVisible(false)
                self._house:getChildByTag(1):getChildByTag(7):getChildByName("Button_6"):setVisible(true)
            end 
        end
        local button_fl6=self._house:getChildByTag(1):getChildByName("Button_f6")
        button_fl6:addTouchEventListener(eventButton_fly6)
        
        local function eventButton_fly7(sender, eventType)
            if eventType == ccui.TouchEventType.ended then 
                AudioEngine.playEffect(EFFECT_FILE_NAME[7])
                cclog("-->7")
                sender:setVisible(false)
                self._house:getChildByTag(1):getChildByTag(7):getChildByName("Button_7"):setVisible(true)
            end 
        end
        local button_fl7=self._house:getChildByTag(1):getChildByName("Button_f7")
        button_fl7:addTouchEventListener(eventButton_fly7)
    end
    initButton()
    local function animationEvent(armatureBack,movementType,movementID)
        local id = movementID
        if movementType == ccs.MovementEventType.complete 
            or movementType == ccs.MovementEventType.loopComplete then
            if id == "wakeup" then
                self:waitAction()
            end
            if id=="wait1" or id=="wait2" then
                self:waitAction()
            end
        end
    end
    self._numberRole:getNode():getAnimation():setMovementEventCallFunc(animationEvent)
    self._numberRole:getNode():getAnimation():play("pop")
    self._popButton=self._widget:getChildByTag(10012):getChildByTag(1):getChildByName("Button_pop")
    local function eventButtonPop(sender, eventType)
    	if eventType == ccui.TouchEventType.ended then 
            sender:setVisible(false)
            self._numberRole:getNode():getAnimation():play("wakeup")
            local function flyOver()
                self._meng:setVisible(true)
                function showOver()
                self._meng:setVisible(false)
                    ccs.ActionManagerEx:getInstance():playActionByName("meng_1.json","out")
                    self._numberRole:getNode():getAnimation():play("wait1")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_1")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_2")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_3")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_4")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_5")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_6")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_7")
                    ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly_8")
                end
                ccs.ActionManagerEx:getInstance():playActionByName("meng_1.json","show",cc.CallFunc:create(showOver))
                AudioEngine.playEffect("dream.mp3") 
                self._numberRole:getNode():getAnimation():play("yume")	
            end
            ccs.ActionManagerEx:getInstance():playActionByName("house_1.json","fly",cc.CallFunc:create(flyOver))
            AudioEngine.playEffect("one.mp3") 
        end 
    end
    self._popButton:addTouchEventListener(eventButtonPop)
end
function gameHouseOne:onEnter()
    cclog("onEnter")
--    AudioEngine.playEffect(EFFECT_FILE, true)
    AudioEngine.playMusic(backMusic, true)
end
function gameHouseOne:onExit()
    ccs.ArmatureDataManager:destroyInstance()
    ccs.SceneReader:destroyInstance()
    ccs.ActionManagerEx:destroyInstance()
    ccs.GUIReader:destroyInstance()
end
function gameHouseOne.create()
    local scene = cc.Scene:create()
    local layer = gameHouseOne.extend(cc.Layer:create())
    layer:init()
    --    local layer= cc.LayerColor:create(cc.c4b(192, 0, 0, 255),200,200)
    if nil ~= layer then
        local function onNodeEvent(event)
            if "enter" == event then
                layer:onEnter()
            elseif "exit" == event then
                layer:onExit()
            end
        end
        layer:registerScriptHandler(onNodeEvent)
    end
    scene:addChild(layer)
    return scene   
end 
function rungameHouseOneScene()
    local _scene = gameHouseOne.create()
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(_scene)
    else
        cc.Director:getInstance():runWithScene(_scene)
    end
end