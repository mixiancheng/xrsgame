require "Cocos2d"
local scheduler = cc.Director:getInstance():getScheduler()
local s = cc.Director:getInstance():getWinSize()
local Login = class("Login")
Login.__index = Login
Login._uiLayer= nil
Login._widget = nil
Login._sceneTitle = nil
Login.Name=nil
Login.Pass=nil
function LoginLayerStep(dt) --@return typeOrObject
end
function Login.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, Login)
    return target
end
function Login:init()
    self._uiLayer = cc.Layer:create()
    self:addChild(self._uiLayer)
    self._widget =ccs.GUIReader:getInstance():widgetFromJsonFile("res/Login_Res/Login_1.json")
--    self._widget:setPosition(521,350)
    self._uiLayer:addChild(self._widget)
end
function Login.create()
    local scene = cc.Scene:create()
    local layer = Login.extend(cc.Layer:create())
    layer:init()
    scene:addChild(layer)
    return scene   
end 
function runCocosLoginScene()
    local _scene = Login.create()
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(_scene)
    else
        cc.Director:getInstance():runWithScene(_scene)
    end
end